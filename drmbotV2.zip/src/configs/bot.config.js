module.exports={
    prefix:'!',
    admin_user:['521330948382654487']
}